<div class="sidebar">
    <h1>StarGO！</h1>
    <h2>歡迎<?php echo htmlspecialchars($username); ?>！</h2>
    <h2>功能區</h2>
    <a href="profile.php">👤 我的帳戶</a>
    <a href="spot_add.php">➕ 新增景點</a>
    <a href="my_posts.php">📜 我的文章</a>
	<a href="index.php">🏠 回主頁</a>
    <a href="logout.php" class="active">登出</a>
</div>
