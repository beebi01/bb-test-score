<header>
    <div class="header-left">
        <h1>📍 熱門景點</h1>
    </div>
</header>
<style>
	
	header:not(.fixed-header) {
    margin-top: 130px;  /* 高度要比第一個 header 高度多一點 */
}

</style>
